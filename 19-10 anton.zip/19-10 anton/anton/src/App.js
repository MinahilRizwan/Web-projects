import './App.css';
import { Page1 } from './Pages/Page1';


function App() {
  return (
   <div>
    <Page1/>
   </div>
  );
}

export default App;
